# opt-docx / scripts

把已成型的 docx 排成 OPT 公司格式的三件套。**正文文字零改动**是这组脚本的铁律——
它们只动样式、尺寸、页码，不碰一个 `w:t` 的内容（目录页码列除外）。

首次跑通：2026-08-25，EML-3X 用户手册（37→45 页 / 31 图 / 8 表 / 42 条静态目录）。
脚本是那一轮实跑代码的整理落盘，不是重写。

| 文件 | 一句话 |
|---|---|
| `apply_template_style.py` | 读模板 styles.xml，把正文/标题1-3/图注样式 + 页面 sectPr 刷到目标 docx，并按新版心等比重算所有表格宽度 |
| `fit_images.py` | 图片按真实宽高比分三档定尺寸，图段 `keepNext` + 图注段 `keepLines` 绑定同页 |
| `measure_toc_pages.py` | Pages 导 PDF → PyMuPDF 按页脚「第 N 页」实测每个标题页码 → 写回目录页码列 → 再导一次复测 |
| `_docx_common.py` | 公共层：解包/回包、命名空间、OOXML 顺序安全插入。三个脚本都 import 它，不单独调用 |

## 依赖

- Python 3.9+，`lxml`、`Pillow`、`PyMuPDF`(fitz)
- 解包/回包借用 docx skill：`~/.claude/skills/docx/scripts/office/{unpack,pack}.py`
- 只有 `measure_toc_pages.py` 需要 macOS + Pages（osascript 驱动）
- 字体：`仿宋_GB2312` 必须装在系统里，否则 Pages 会替换字体，实测出来的分页是假的

## 固定跑法（顺序不能换）

```bash
S=~/.claude/skills/opt-docx/scripts
python3 $S/apply_template_style.py 手册.docx                       # 1 样式
python3 $S/fit_images.py      手册.docx --start-index 12      # 2 图片（跳过封面）
python3 $S/measure_toc_pages.py 手册.docx --pdf-out 手册.pdf   # 3 页码（必须最后）
```

**3 必须最后**：样式或图片尺寸一改分页就变，先测的页码全部作废。

## 入参签名

### `apply_template_style.py TARGET.docx`

| 参数 | 默认 | 说明 |
|---|---|---|
| `TARGET` | 必填 | 目标 .docx，默认就地覆盖 |
| `--template` | `~/Documents/文档/DOC/文档模板.docx` | 样式真源 |
| `--out` | 覆盖 target | 另存路径 |
| `--body-start` | 自动 | 正文起始 body 段落序号；自动探测＝第一个一级标题之前最后一个分节符的下一段 |
| `--table-sz` | 正文字号-3 | 表格文字半磅值（12pt 正文 → 21 即 10.5pt） |
| `--caption-regex` | `^图[\s　]*\d` | 图注识别 |
| `--keep-fig-indent` | 关 | 保留模板「图」样式自带的悬挂缩进 |
| `--fig-ascii-from-template` | 关 | 图注西文字体照抄模板 |
| `--no-table-rescale` | 关 | 不重算表格宽度 |
| `--dry-run` | 关 | 只打印模板读到的值，不落盘 |

自动探测的东西会打印出来，跑完请核一眼：正文起点、正文主字号、sectPr 个数、
表格张数、派生样式列表、各类 run 改写计数。

### `fit_images.py TARGET.docx`

| 参数 | 默认 | 说明 |
|---|---|---|
| `TARGET` | 必填 | 目标 .docx |
| `--out` | 覆盖 target | 另存路径 |
| `--max-width-px` | 530 | 版心可用宽（A4 + 左右 1800dxa） |
| `--wide-ar` / `--tall-ar` | 1.6 / 0.8 | 分档判据 |
| `--square-max-h-pt` | 300 | 方形档限高 |
| `--tall-max-h-pt` | 340 | 竖高档限高 |
| `--start-index` | 0 | 从第几个 body 段落开始（跳过封面） |
| `--skip-images` | 0 | 跳过前 N 张图 |
| `--caption-regex` | `^图[\s　]*\d` | 图注识别（决定 keepLines 加给谁） |
| `--no-keep` | 关 | 不加 keepNext/keepLines |
| `--dry-run` | 关 | 只出尺寸表不落盘 |

输出是一张逐图对照表（源尺寸 / 宽高比 / 档 / 原 px / 新 px / 新 pt）+ 分档统计。

### `measure_toc_pages.py TARGET.docx`

| 参数 | 默认 | 说明 |
|---|---|---|
| `TARGET` | 必填 | 目标 .docx，页码就地写回 |
| `--out` | 覆盖 target | docx 另存路径 |
| `--pdf-out` | 临时文件 | 终版 PDF 落盘路径 |
| `--toc-table` | 自动 | 目录是第几张表（0 起）；自动＝含内部超链接域最多的那张 |
| `--title-col` / `--page-col` | 0 / -1 | 条目列 / 页码列 |
| `--footer-regex` | `第\s*\n?\s*(\d+)?\s*页\s*\n?\s*(\d+)?` | 页脚页码，第一个非空捕获组即页码 |
| `--footer-band-pt` | 70 | 距页底多少 pt 内算页脚 |
| `--pages-delay` | 3 | Pages 打开后等待秒数，大文档调大 |
| `--no-quit-pages` | 关 | 导出前不退出 Pages |
| `--measure-only` | 关 | 只实测报告，不写回 |

## 已知坑（都是实测踩出来的）

**样式层**

- **直接格式压过样式**。源文档里 90% 的 run 自带 `w:sz` 和 `w:rFonts`，只改
  styles.xml 等于什么都没改。`apply_template_style.py` 因此必须同时重写 run 级属性——
  它靠"检出正文主字号"（非表格非标题段落里出现最多的那个字号）来判断哪些 run 是
  正文、哪些是注解，跑完请核对打印出来的那个数。
- **改版心必须同步改表格宽度**。左右边距 1440→1800，版心从 9026 掉到 8306 dxa，
  表格若还是 9026 会直接溢出。`tblW` / `gridCol` / `tcW` 三处都要改，漏 `tcW`
  会出现"表框对了、单元格错位"。
- **行距会往前置节传染**。Normal 一旦设成 `line=360`，封面、目录、表格里所有没写
  显式行距的段落全部跟着变 1.5 倍，目录直接撑长、表格整体撑高。做法是给正文起点
  之前的所有段落 + 所有表格段落显式钉 `line=240`。
- **模板「图」样式自带 `ind left=900 hanging=420`**。那是给自动编号图注用的悬挂
  缩进；手写编号 + 居中的图注套上去会整体右移、首行错位。默认剥掉，
  `--keep-fig-indent` 可留。
- **模板「图」样式的 ascii 是 仿宋_GB2312**。照抄会让图注里的数字和英文也变仿宋。
  默认改成跟随正文西文字体，`--fig-ascii-from-template` 可照抄。
- **模板派生文档的 styles.xml 本来就不合 schema**（`uiPriority` 排在 `qFormat`
  之后）。校验必须带原件当基线（`pack.py --original`），否则会误报 3 条 new error。
  `_docx_common.Docx` 已经这么做了。
- **`w:pPr` / `w:rPr` 的子元素顺序是强制的**，插错位置 Word 能打开但 schema 会红。
  一律走 `get_or_make(parent, tag, ORDER)`，不要 `SubElement` 直接 append。
- （SKILL.md 已载）**Pages 会把居中样式"传染"给后续无显式样式的段落** → 生成文档时
  每段都显式挂样式（BodyP / CenterP / RightP）。

**图片层**

- **`wp:extent` 和 `a:ext` 要一起改**，只改一个 Word 会按另一个渲染。
- **`a:extLst` 底下也有 `a:ext`**，但那种带 `uri`、没有 `cx`——碰它会造出非法属性。
  改之前必须判 `e.get('cx') is not None`。
- **判据用真实像素比，不能用当前 extent 比**。当前 extent 可能已经被人手拉变形过。
- 分档边界是 `>=` / `<`：宽高比正好 0.800 的图落在"方形"档，不落"竖高"档。

**页码层**

- **同名文本会先在目录里命中**。必须从"页脚第一次出现第 1 页"的那页开始找，
  并且游标只许单调前进。
- **Pages 会话残留**。同一个 Pages 会话里连着导第二份 PDF，实测出现过上一份的残留
  字符被画进新 PDF（0825：封面左边凭空多一个 `c`，XML 里根本没有）。所以默认
  每次导出前先 `quit Pages`；成品 PDF 一定要目检首页。
- **页码是独立 run**，PDF 抽出来常常是 `第  页\n7` 这种形状，正则要能吃下换行分离。
- **只支持表格式静态目录**（条目列 + 页码列）。TOC 域式目录不在处理范围——那种目录
  收件人不刷新就显示为空，WPS 尤甚，本来就不该用；Pages 还会把域炸成十几页。
  （相关：Pages 忽略正文段落里的自定义制表位，前导点+右对齐页码必错位，这也是
  目录必须做成表格的原因。）
- **写页码本身可能改变分页**（位数 1 位变 2 位撑行）。第二遍复测不一致时，把结果
  再跑一次脚本即可收敛；脚本会明确报"未收敛"而不是默默过去。

## 验收

- docx：`pack.py --original 原件` 报 `All validations PASSED!`，段落数不变
- 文字零改动：逐 `w:t` 比对原件与新件，目录以外必须完全一致
- PDF：目检首页 + 抽验 5 条目录页码；**终验收要在 WPS/Word 里看首屏**，
  别只查 XML（空目录、字号不统一这类"打开第一眼"的缺陷，XML 检查全过也照样存在）
