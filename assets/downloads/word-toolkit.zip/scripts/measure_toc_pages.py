#!/usr/bin/env python3
"""静态目录页码实测：Pages 导 PDF -> 按页脚定位每个标题真实页码 -> 写回目录 -> 复测。

样式或图片尺寸一改，分页必变，目录里所有页码同时作废。这个脚本把"实测"这件事
做成两遍法：

    第一遍  导 PDF -> 逐页读页脚「第 N 页」-> 在正文里找每个目录条目对应的标题行
            -> 得到真实页码 -> 写回目录表的页码列
    第二遍  再导一次 PDF -> 重新实测 -> 与写进去的值逐条比对，全对才算过

适用的目录形态：**表格式静态目录**（条目列 + 页码列，条目里是指向书签的
HYPERLINK \\l "bookmark" 域）。TOC 域式目录不在处理范围内——那种目录在收件人
不刷新时会显示为空，本来就不该用。

用法：
    python3 measure_toc_pages.py TARGET.docx [选项]

    python3 measure_toc_pages.py 手册.docx
    python3 measure_toc_pages.py 手册.docx --pdf-out 手册.pdf     # 顺便留下终版 PDF
    python3 measure_toc_pages.py 手册.docx --toc-table 0          # 手工指定目录表
    python3 measure_toc_pages.py 手册.docx --measure-only         # 只报不写
"""
import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time

import fitz
from lxml import etree

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _docx_common import Docx, W, body_children, q, text_of  # noqa: E402


# ------------------------------------------------------------------ Pages
EXPORT_SCPT = '''
set inFile to POSIX file "{inp}"
set outFile to POSIX file "{out}"
tell application "Pages"
    activate
    set d to open inFile
    delay {delay}
    export d to outFile as PDF
    delay 1
    close d saving no
end tell
'''


def export_pdf(docx, pdf, delay=3, quit_first=True):
    """osascript 驱动 Pages 导 PDF。

    🔴 quit_first 默认开：同一个 Pages 会话里连着导第二份，实测出现过上一份的
    残留字符被画进新 PDF（0825：封面左边多出一个孤零零的 "c"，XML 里根本没有）。
    退出 Pages 再开就干净。
    """
    if quit_first:
        subprocess.run(['osascript', '-e', 'tell application "Pages" to quit'],
                       capture_output=True)
        time.sleep(2)
    if os.path.exists(pdf):
        os.remove(pdf)
    scpt = EXPORT_SCPT.format(inp=os.path.abspath(docx), out=os.path.abspath(pdf),
                              delay=delay)
    p = subprocess.run(['osascript', '-e', scpt], capture_output=True, text=True)
    if not os.path.exists(pdf):
        raise RuntimeError(f'Pages 导出失败：{p.stdout}\n{p.stderr}')
    return pdf


# ---------------------------------------------------------------- measure
def footer_numbers(doc, footer_band_pt, footer_regex):
    """每页页脚里的「第 N 页」。页码是独立 run，抽出来常常是 '第  页\\n7'。"""
    rx = re.compile(footer_regex)
    out = {}
    for i, p in enumerate(doc):
        h = p.rect.height
        s = ' '.join(b[4] for b in p.get_text('blocks') if b[3] > h - footer_band_pt)
        m = rx.search(s)
        n = None
        if m:
            n = next((g for g in m.groups() if g), None)
        out[i] = int(n) if n else None
    return out


def page_lines(doc):
    res = {}
    for i, p in enumerate(doc):
        ls = []
        for blk in p.get_text('dict')['blocks']:
            if blk.get('type') != 0:
                continue
            for ln in blk['lines']:
                t = ''.join(sp['text'] for sp in ln['spans']).strip()
                if t:
                    ls.append(t)
        res[i] = ls
    return res


def norm(s):
    return re.sub(r'\s+', '', s)


def measure(pdf, headings, footer_band_pt, footer_regex):
    """返回 (每条标题的实测页码, 总页数, 未找到的条目)。

    从页脚第一次出现「第 1 页」的那页开始找——正文之前的封面/目录里有同名文本，
    从头找会全部命中目录自己那一行。
    """
    doc = fitz.open(pdf)
    foot = footer_numbers(doc, footer_band_pt, footer_regex)
    lines = page_lines(doc)
    start = next((i for i in sorted(foot) if foot[i] == 1), 0)

    nums, missing = [], []
    cursor = start
    for h in headings:
        nh = norm(h)
        found = None
        for i in range(cursor, doc.page_count):
            if any(norm(t) == nh for t in lines[i]):
                found = i
                break
        if found is None:                       # 放宽到行首匹配
            for i in range(cursor, doc.page_count):
                if any(norm(t).startswith(nh) for t in lines[i]):
                    found = i
                    break
        if found is None:
            missing.append(h)
            nums.append(None)
            continue
        cursor = found                          # 单调推进，防倒着命中
        nums.append(foot[found])
    n = doc.page_count
    doc.close()
    return nums, n, missing


# -------------------------------------------------------------------- TOC
def find_toc_table(kids, explicit=None):
    """目录表 = 含 HYPERLINK \\l 域最多的那张表。"""
    tables = [(i, el) for i, el in enumerate(kids)
              if etree.QName(el).localname == 'tbl']
    if explicit is not None:
        return tables[explicit][1], tables[explicit][0]
    best, best_n, best_i = None, 0, None
    for i, t in tables:
        n = sum(1 for x in t.iter(q('instrText'))
                if 'HYPERLINK' in (x.text or '') and '\\l' in (x.text or ''))
        if n > best_n:
            best, best_n, best_i = t, n, i
    if best is None:
        raise SystemExit('没找到含内部超链接的目录表；用 --toc-table 手工指定序号')
    return best, best_i


def toc_entries(tbl, title_col, page_col):
    out = []
    for tr in tbl.findall(q('tr')):
        tcs = tr.findall(q('tc'))
        if len(tcs) < 2:
            continue
        title = text_of(tcs[title_col]).strip()
        ts = [x for x in tcs[page_col].iter(q('t'))]
        out.append((title, ts))
    return out


def main():
    ap = argparse.ArgumentParser(description='目录页码实测并写回（两遍法）')
    ap.add_argument('target', help='目标 .docx（页码就地写回）')
    ap.add_argument('--out', default=None, help='docx 另存路径（不给则覆盖 target）')
    ap.add_argument('--pdf-out', default=None,
                    help='终版 PDF 落盘路径；不给则只用临时文件')
    ap.add_argument('--toc-table', type=int, default=None,
                    help='目录表是第几张表（0 起）；不给则自动认')
    ap.add_argument('--title-col', type=int, default=0, help='条目列序号')
    ap.add_argument('--page-col', type=int, default=-1, help='页码列序号，默认最后一列')
    ap.add_argument('--footer-regex', default=r'第\s*\n?\s*(\d+)?\s*页\s*\n?\s*(\d+)?',
                    help='页脚页码正则，第一个非空捕获组即页码')
    ap.add_argument('--footer-band-pt', type=float, default=70,
                    help='页脚判定带（距页底多少 pt 内算页脚）')
    ap.add_argument('--pages-delay', type=float, default=3,
                    help='Pages 打开文档后的等待秒数，大文档调大')
    ap.add_argument('--no-quit-pages', action='store_true',
                    help='导出前不退出 Pages（会有残留字符风险）')
    ap.add_argument('--measure-only', action='store_true',
                    help='只实测并报告，不写回、不改文件')
    args = ap.parse_args()

    tmp = tempfile.mkdtemp(prefix='opttoc_')
    try:
        # ---------- 读目录条目（只读，不解包回包）
        import zipfile
        raw = zipfile.ZipFile(args.target).read('word/document.xml')
        kids = list(etree.fromstring(raw).find(q('body')))
        tbl, tbl_i = find_toc_table(kids, args.toc_table)
        headings = [t for t, _ in toc_entries(tbl, args.title_col, args.page_col)]
        print(f'目录表 = body[{tbl_i}]，共 {len(headings)} 条')

        # ---------- 第一遍
        pdf1 = os.path.join(tmp, 'pass1.pdf')
        export_pdf(args.target, pdf1, args.pages_delay, not args.no_quit_pages)
        nums, npages, missing = measure(pdf1, headings, args.footer_band_pt,
                                        args.footer_regex)
        print(f'第一遍：PDF {npages} 页；实测页码 {nums}')
        if missing:
            print(f'🔴 有 {len(missing)} 条在正文里没找到：{missing}')
            raise SystemExit(1)
        if args.measure_only:
            for h, n in zip(headings, nums):
                print(f'  {h}  ->  {n}')
            return

        # ---------- 写回
        out = args.out or args.target
        with Docx(args.target, out=out) as d:
            dtree = d.parse('document.xml')
            kids = body_children(dtree)
            tbl, _ = find_toc_table(kids, args.toc_table)
            entries = toc_entries(tbl, args.title_col, args.page_col)
            changed = 0
            for (title, ts), n in zip(entries, nums):
                if len(ts) != 1:
                    print(f'⚠️ 「{title}」页码单元格有 {len(ts)} 个文本节点，跳过')
                    continue
                if ts[0].text != str(n):
                    ts[0].text = str(n)
                    changed += 1
            d.write(dtree, 'document.xml')
        print(f'写回目录页码：{changed} / {len(nums)} 条有变化')

        # ---------- 第二遍复测
        pdf2 = args.pdf_out or os.path.join(tmp, 'pass2.pdf')
        export_pdf(out, pdf2, args.pages_delay, not args.no_quit_pages)
        nums2, npages2, missing2 = measure(pdf2, headings, args.footer_band_pt,
                                           args.footer_regex)
        ok = sum(1 for a, b in zip(nums, nums2) if a == b)
        print(f'第二遍：PDF {npages2} 页；复测一致 {ok} / {len(nums)}')
        if ok != len(nums) or missing2:
            bad = [(h, a, b) for h, a, b in zip(headings, nums, nums2) if a != b]
            print(f'🔴 未收敛：{bad}')
            print('   —— 写页码本身改变了分页（多半是位数从 1 位变 2 位撑行），'
                  '把第二遍结果再跑一次本脚本即可收敛')
            raise SystemExit(1)
        print(f'✅ {len(nums)}/{len(nums)} 一致，页码全部实测')
        if args.pdf_out:
            print(f'终版 PDF: {args.pdf_out}')
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == '__main__':
    main()
