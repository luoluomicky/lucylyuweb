#!/usr/bin/env python3
"""opt-docx 脚本组的公共层：解包/回包、命名空间、OOXML 顺序安全插入。

三个脚本（apply_template_style / fit_images / measure_toc_pages）都 import 它。
依赖：lxml、Pillow；解包回包借用 docx skill 的 scripts/office/{unpack,pack}.py。
"""
import os
import shutil
import subprocess
import sys
import tempfile

from lxml import etree

# ---------------------------------------------------------------- namespaces
W  = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
A  = '{http://schemas.openxmlformats.org/drawingml/2006/main}'
WP = '{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}'
R  = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'
NSR = 'http://schemas.openxmlformats.org/package/2006/relationships'

EMU_PX = 9525      # 1 px @96dpi
EMU_PT = 12700     # 1 pt

DOCX_SKILL = os.path.expanduser('~/.claude/skills/docx/scripts/office')


def q(tag):
    return W + tag


# ------------------------------------------------------------ unpack / pack
def _run(script, *args):
    cmd = [sys.executable, os.path.join(DOCX_SKILL, script), *args]
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode != 0:
        raise RuntimeError(f'{script} failed:\n{p.stdout}\n{p.stderr}')
    return p.stdout.strip()


class Docx:
    """with Docx(path) as d:  改 d.word/document.xml ...  ；退出时自动回包。

    original 用于回包时的校验基线——文档模板派生的文件 styles.xml 里
    uiPriority 的位置本来就不合 schema，没有基线就会误报 3 条 new error。
    """

    def __init__(self, path, out=None, validate=True):
        self.path = os.path.abspath(path)
        self.out = os.path.abspath(out) if out else self.path
        self.validate = validate
        self.tmp = None

    def __enter__(self):
        self.tmp = tempfile.mkdtemp(prefix='optdocx_')
        self.dir = os.path.join(self.tmp, 'unpacked')
        # 原件副本：既是回包基线，也是失败时的兜底
        self.original = os.path.join(self.tmp, 'original.docx')
        shutil.copy(self.path, self.original)
        print(_run('unpack.py', self.path, self.dir))
        self.word = os.path.join(self.dir, 'word')
        return self

    def __exit__(self, exc_type, exc, tb):
        try:
            if exc_type is None:
                print(_run('pack.py', self.dir, self.out,
                           '--original', self.original,
                           '--validate', 'true' if self.validate else 'false'))
        finally:
            shutil.rmtree(self.tmp, ignore_errors=True)
        return False

    # --- xml helpers ---
    def parse(self, name):
        return etree.parse(os.path.join(self.word, name))

    def write(self, tree, name):
        tree.write(os.path.join(self.word, name),
                   xml_declaration=True, encoding='UTF-8', standalone=True)


# --------------------------------------------------- schema-ordered insert
# CT_PPr / CT_RPr 的子元素顺序是强制的，插错位置 Word 能开、schema 校验会红。
PPR_ORDER = ['pStyle', 'keepNext', 'keepLines', 'pageBreakBefore', 'framePr',
             'widowControl', 'numPr', 'pBdr', 'shd', 'tabs', 'snapToGrid',
             'spacing', 'ind', 'contextualSpacing', 'jc', 'textAlignment',
             'outlineLvl', 'rPr', 'sectPr']
RPR_ORDER = ['rStyle', 'rFonts', 'b', 'bCs', 'i', 'iCs', 'caps', 'smallCaps',
             'strike', 'noProof', 'snapToGrid', 'color', 'spacing', 'w', 'kern',
             'position', 'sz', 'szCs', 'highlight', 'u', 'vertAlign', 'rtl',
             'cs', 'em', 'lang']
STYLE_ORDER = ['name', 'aliases', 'basedOn', 'next', 'link', 'autoRedefine',
               'hidden', 'uiPriority', 'semiHidden', 'unhideWhenUsed', 'qFormat',
               'locked', 'personal', 'rsid', 'pPr', 'rPr', 'tblPr', 'trPr',
               'tcPr', 'tblStylePr']


def get_or_make(parent, tag, order):
    """取 parent 下的 w:<tag>，没有就按 schema 顺序插到正确位置。"""
    el = parent.find(q(tag))
    if el is not None:
        return el
    idx = {t: i for i, t in enumerate(order)}
    mine = idx[tag]
    el = etree.Element(q(tag))
    pos = len(parent)
    for n, c in enumerate(parent):
        o = idx.get(etree.QName(c).localname)
        if o is not None and o > mine:
            pos = n
            break
    parent.insert(pos, el)
    return el


def pPr(p):
    pr = p.find(q('pPr'))
    if pr is None:
        pr = etree.Element(q('pPr'))
        p.insert(0, pr)
    return pr


def rPr(r):
    pr = r.find(q('rPr'))
    if pr is None:
        pr = etree.Element(q('rPr'))
        r.insert(0, pr)
    return pr


def set_spacing(p, line=None, before=None, after=None):
    sp = get_or_make(pPr(p), 'spacing', PPR_ORDER)
    if line is not None:
        sp.set(W + 'line', str(line))
        sp.set(W + 'lineRule', 'auto')
    if before is not None:
        sp.set(W + 'before', str(before))
    if after is not None:
        sp.set(W + 'after', str(after))


def set_flag(p, tag):
    get_or_make(pPr(p), tag, PPR_ORDER)


def set_pstyle(p, val):
    get_or_make(pPr(p), 'pStyle', PPR_ORDER).set(W + 'val', val)


def get_pstyle(p):
    st = p.find(q('pPr') + '/' + q('pStyle'))
    return st.get(W + 'val') if st is not None else None


def set_sz(r, val):
    pr = rPr(r)
    for tag in ('sz', 'szCs'):
        get_or_make(pr, tag, RPR_ORDER).set(W + 'val', str(val))


def get_sz(r):
    pr = r.find(q('rPr'))
    if pr is None:
        return None
    sz = pr.find(q('sz'))
    return int(sz.get(W + 'val')) if sz is not None else None


def get_ea(r):
    pr = r.find(q('rPr'))
    if pr is None:
        return None
    rf = pr.find(q('rFonts'))
    return rf.get(W + 'eastAsia') if rf is not None else None


def set_ea(r, font):
    get_or_make(rPr(r), 'rFonts', RPR_ORDER).set(W + 'eastAsia', font)


def drop(r, tag):
    pr = r.find(q('rPr'))
    if pr is None:
        return
    for el in pr.findall(q(tag)):
        pr.remove(el)


def text_of(el):
    return ''.join(x.text or '' for x in el.iter(q('t')))


def body_children(tree):
    return list(tree.getroot().find(q('body')))


def has_drawing(p):
    return p.find('.//' + q('drawing')) is not None
