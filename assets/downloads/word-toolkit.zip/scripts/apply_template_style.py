#!/usr/bin/env python3
"""把模板的样式刷到目标 docx（就地或另存），正文一个字不动。

做四件事：
  1) 从模板 styles.xml 按**样式名**（Normal / heading 1-3 / 图）读出字体·字号·行距，
     写进目标文档的同名样式；模板的「图」样式（a3 + 字符样式 a4）整份搬过来。
  2) 页面设置：模板 body sectPr 的 pgSz + pgMar 刷到目标的**每一个** sectPr。
  3) 版心变宽变窄后按新版心等比重算所有表格宽度（tblW / gridCol / tcW 三处）。
  4) 段落/字符级的直接格式（direct formatting）跟着改——只有这一步做了，
     样式改动才真的生效：源文档 90% 的 run 都带自己的 w:sz 和 w:rFonts，
     它们优先级高于样式，不重写就等于什么都没改。

用法：
    python3 apply_template_style.py TARGET.docx [--template TPL.docx] [选项]

    python3 apply_template_style.py 手册.docx                       # 就地改
    python3 apply_template_style.py 手册.docx --out 手册-新版.docx    # 另存
    python3 apply_template_style.py 手册.docx --body-start 12 --table-sz 21
    python3 apply_template_style.py 手册.docx --dry-run             # 只报计划不落盘
"""
import argparse
import collections
import os
import re
import shutil
import sys
import tempfile

from lxml import etree

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _docx_common import (  # noqa: E402
    W, Docx, _run, PPR_ORDER, RPR_ORDER, STYLE_ORDER, body_children, drop,
    get_ea, get_or_make, get_pstyle, get_sz, has_drawing, pPr, q, rPr,
    set_ea, set_flag, set_pstyle, set_spacing, set_sz, text_of,
)

# 默认模板：与本脚本同级目录下的「文档模板-空白版.docx」。
# 换成你们自己的模板：把 --template 指向那个 docx，或直接改这一行。
DEFAULT_TEMPLATE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), '文档模板-空白版.docx')

# 模板里这些样式按「名字」找，因为 styleId 在不同文档里完全不同
# （模板是 a/1/2/3，Pandoc 生成的是 Normal/Heading1，WPS 生成的是纯数字）
NAME_NORMAL = 'normal'
NAME_HEADINGS = ['heading 1', 'heading 2', 'heading 3']
NAME_FIG = '图'


# --------------------------------------------------------------- 读模板
def style_by_name(root, name):
    for s in root.findall(q('style')):
        n = s.find(q('name'))
        if n is not None and n.get(W + 'val').strip().lower() == name.lower():
            return s
    return None


def read_spec(s):
    """从一个 w:style 里抽出我们关心的几个值。"""
    out = {}
    if s is None:
        return out
    rpr = s.find(q('rPr'))
    if rpr is not None:
        rf = rpr.find(q('rFonts'))
        if rf is not None:
            out['ea'] = rf.get(W + 'eastAsia')
            out['ascii'] = rf.get(W + 'ascii')
            out['hAnsi'] = rf.get(W + 'hAnsi')
        sz = rpr.find(q('sz'))
        if sz is not None:
            out['sz'] = int(sz.get(W + 'val'))
    ppr = s.find(q('pPr'))
    if ppr is not None:
        sp = ppr.find(q('spacing'))
        if sp is not None:
            for k, attr in (('line', 'line'), ('before', 'before'), ('after', 'after')):
                v = sp.get(W + attr)
                if v is not None:
                    out[k] = int(v)
        out['keep'] = ppr.find(q('keepNext')) is not None
        out['jc'] = (ppr.find(q('jc')).get(W + 'val')
                     if ppr.find(q('jc')) is not None else None)
    return out


def load_template(path):
    """只读模板，不回包。"""
    tmp = tempfile.mkdtemp(prefix='opttpl_')
    try:
        _run('unpack.py', path, tmp)
        wd = os.path.join(tmp, 'word')
        st = etree.parse(os.path.join(wd, 'styles.xml')).getroot()
        spec = {
            'normal': read_spec(style_by_name(st, NAME_NORMAL)),
            'h': [read_spec(style_by_name(st, n)) for n in NAME_HEADINGS],
            'fig': read_spec(style_by_name(st, NAME_FIG)),
        }
        sect = etree.parse(os.path.join(wd, 'document.xml')).getroot() \
                    .find(q('body') + '/' + q('sectPr'))
        spec['pgSz'] = dict(sect.find(q('pgSz')).attrib) if sect is not None else {}
        spec['pgMar'] = dict(sect.find(q('pgMar')).attrib) if sect is not None else {}
        return spec
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# --------------------------------------------------------------- 写目标
def cfg_style(s, *, ea=None, sz=None, line=None, before=None, after=None, keep=False):
    if s is None:
        return
    if line is not None or before is not None or after is not None or keep:
        ppr = get_or_make(s, 'pPr', STYLE_ORDER)
        if line is not None or before is not None or after is not None:
            sp = get_or_make(ppr, 'spacing', PPR_ORDER)
            if line is not None:
                sp.set(W + 'line', str(line))
                sp.set(W + 'lineRule', 'auto')
            if before is not None:
                sp.set(W + 'before', str(before))
            if after is not None:
                sp.set(W + 'after', str(after))
        if keep:
            get_or_make(ppr, 'keepNext', PPR_ORDER)
            get_or_make(ppr, 'keepLines', PPR_ORDER)
    if ea is not None or sz is not None:
        rpr = get_or_make(s, 'rPr', STYLE_ORDER)
        if ea is not None:
            get_or_make(rpr, 'rFonts', RPR_ORDER).set(W + 'eastAsia', ea)
        if sz is not None:
            for t in ('sz', 'szCs'):
                get_or_make(rpr, t, RPR_ORDER).set(W + 'val', str(sz))


FIG_STYLE_ID = 'a3'
FIG_CHAR_ID = 'a4'


def add_fig_style(root, fig, normal_id, default_char_id, keep_indent):
    """把模板的「图」样式装进目标文档。

    🔴 模板自带 ind left=900 hanging=420 —— 那是给"图 1-1"自动编号用的悬挂缩进，
    手写编号 + 居中的图注套上去会整体右移且首行错位，默认剥掉。
    """
    if any(s.get(W + 'styleId') == FIG_STYLE_ID for s in root.findall(q('style'))):
        return False
    ea = fig.get('ea') or '仿宋_GB2312'
    asc = fig.get('ascii') or 'Times New Roman'
    han = fig.get('hAnsi') or 'Times New Roman'
    sz = fig.get('sz') or 24
    ind = ''
    if keep_indent:
        ind = '<w:ind w:left="900" w:hanging="420"/>'
    ns = W[1:-1]
    para = etree.fromstring(
        f'<w:style xmlns:w="{ns}" w:type="paragraph" w:customStyle="1" '
        f'w:styleId="{FIG_STYLE_ID}"><w:name w:val="图"/>'
        f'<w:basedOn w:val="{normal_id}"/><w:next w:val="{normal_id}"/>'
        f'<w:link w:val="{FIG_CHAR_ID}"/><w:qFormat/>'
        f'<w:pPr><w:spacing w:before="60" w:after="200" w:line="240" '
        f'w:lineRule="auto"/>{ind}<w:jc w:val="center"/></w:pPr>'
        f'<w:rPr><w:rFonts w:ascii="{asc}" w:eastAsia="{ea}" w:hAnsi="{han}"/>'
        f'<w:sz w:val="{sz}"/><w:szCs w:val="{sz}"/></w:rPr></w:style>')
    char = etree.fromstring(
        f'<w:style xmlns:w="{ns}" w:type="character" w:customStyle="1" '
        f'w:styleId="{FIG_CHAR_ID}"><w:name w:val="图 字符"/>'
        f'<w:basedOn w:val="{default_char_id}"/><w:link w:val="{FIG_STYLE_ID}"/>'
        f'<w:rPr><w:rFonts w:ascii="{asc}" w:eastAsia="{ea}" w:hAnsi="{han}"/>'
        f'<w:sz w:val="{sz}"/><w:szCs w:val="{sz}"/></w:rPr></w:style>')
    root.append(para)
    root.append(char)
    return True


def resolve_ids(root):
    """目标文档里 Normal / heading1-3 / 默认字符样式 的 styleId。"""
    ids = {'headings': [None, None, None]}
    for s in root.findall(q('style')):
        n = s.find(q('name'))
        nm = n.get(W + 'val').strip().lower() if n is not None else ''
        sid = s.get(W + 'styleId')
        if nm == NAME_NORMAL and s.get(W + 'type') == 'paragraph':
            ids['normal'] = sid
        if nm == 'default paragraph font':
            ids['charDefault'] = sid
        for i, h in enumerate(NAME_HEADINGS):
            if nm == h:
                ids['headings'][i] = sid
    ids.setdefault('normal', '1')
    ids.setdefault('charDefault', 'a0')
    return ids


def detect_body_start(kids, head_ids):
    """正文起点 = 第一个一级标题之前、最后一个带分节符的段落的下一段。

    封面/目录属于前置节，它们的行距要冻结在原样，不能跟着正文一起变成 1.5 倍。
    """
    first_h1 = None
    for i, el in enumerate(kids):
        if etree.QName(el).localname == 'p' and get_pstyle(el) == head_ids[0]:
            first_h1 = i
            break
    if first_h1 is None:
        return 0
    last_break = -1
    for i in range(first_h1):
        el = kids[i]
        if etree.QName(el).localname == 'p' and el.find(q('pPr') + '/' + q('sectPr')) is not None:
            last_break = i
    return last_break + 1


def dominant_body_sz(kids, start, head_ids):
    """正文主字号 = 非表格、非标题段落里出现次数最多的直接字号。"""
    c = collections.Counter()
    for i in range(start, len(kids)):
        el = kids[i]
        if etree.QName(el).localname != 'p' or has_drawing(el):
            continue
        if get_pstyle(el) in head_ids:
            continue
        for r in el.findall(q('r')):
            v = get_sz(r)
            if v:
                c[v] += 1
    return c.most_common(1)[0][0] if c else None


def main():
    ap = argparse.ArgumentParser(description='把模板样式刷到 docx')
    ap.add_argument('target', help='目标 .docx（默认就地改）')
    ap.add_argument('--template', default=DEFAULT_TEMPLATE, help='样式真源模板 .docx')
    ap.add_argument('--out', default=None, help='另存路径（不给则覆盖 target）')
    ap.add_argument('--body-start', type=int, default=None,
                    help='正文起始 body 段落序号；不给则自动探测（封面/目录之后）')
    ap.add_argument('--table-sz', type=int, default=None,
                    help='表格文字半磅值；默认 = 正文字号 - 3（12pt -> 10.5pt）')
    ap.add_argument('--note-scale', action='store_true', default=True,
                    help='比正文小的注解字号按同一比例放大（默认开）')
    ap.add_argument('--caption-regex', default=r'^图[\s　]*\d',
                    help='图注识别正则，默认匹配「图 1-1 ...」')
    ap.add_argument('--keep-fig-indent', action='store_true',
                    help='保留模板「图」样式自带的 ind 悬挂缩进（默认剥掉）')
    ap.add_argument('--fig-ascii-from-template', action='store_true',
                    help='图注西文字体照抄模板（默认跟随正文西文字体）')
    ap.add_argument('--no-table-rescale', action='store_true',
                    help='不重算表格宽度')
    ap.add_argument('--dry-run', action='store_true', help='只打印计划，不落盘')
    args = ap.parse_args()

    spec = load_template(args.template)
    norm, heads, fig = spec['normal'], spec['h'], spec['fig']
    body_sz = norm.get('sz', 24)
    # 模板「图」样式的 rPr 只写了 ascii，eastAsia/sz 靠继承 Normal —— 补齐，
    # 否则后面按值写直接格式时会拿到 None。
    fig['ea'] = fig.get('ea') or norm.get('ea')
    fig['sz'] = fig.get('sz') or body_sz
    # 🔴 模板「图」的 ascii 是 仿宋_GB2312，照抄会让图注里的数字/英文也变仿宋。
    # 默认跟随正文的西文字体（西文保持现状）；--fig-ascii-from-template 可照抄模板。
    if not args.fig_ascii_from_template:
        fig['ascii'] = norm.get('ascii') or 'Times New Roman'
        fig['hAnsi'] = norm.get('hAnsi') or fig['ascii']
    tbl_sz = args.table_sz if args.table_sz else max(18, body_sz - 3)
    cap_re = re.compile(args.caption_regex)

    print(f'模板 {os.path.basename(args.template)}：'
          f'正文 {norm.get("ea")} sz={body_sz} line={norm.get("line")}；'
          f'标题 ' + ' / '.join(f'sz={h.get("sz")} line={h.get("line")}' for h in heads))
    print(f'页面 pgMar={spec["pgMar"]}')
    if args.dry_run:
        return

    with Docx(args.target, out=args.out) as d:
        # ---- styles.xml
        stree = d.parse('styles.xml')
        sroot = stree.getroot()
        ids = resolve_ids(sroot)
        head_ids = ids['headings']
        by_id = {s.get(W + 'styleId'): s for s in sroot.findall(q('style'))}

        cfg_style(by_id.get(ids['normal']), ea=norm.get('ea'), sz=body_sz,
                  line=norm.get('line'))
        for i, hid in enumerate(head_ids):
            if hid:
                cfg_style(by_id.get(hid), ea=heads[i].get('ea'), sz=heads[i].get('sz'),
                          line=heads[i].get('line'), before=heads[i].get('before'),
                          after=heads[i].get('after'), keep=True)
        # 基于 Normal 的自定义正文样式（BodyP/CenterP/RightP 之流）跟着走
        derived = []
        for s in sroot.findall(q('style')):
            sid = s.get(W + 'styleId')
            if sid in (ids['normal'],) or sid in head_ids:
                continue
            if s.get(W + 'type') != 'paragraph':
                continue
            nm = s.find(q('name'))
            nmv = nm.get(W + 'val') if nm is not None else ''
            if re.search(r'(body|center|right)\s*p', nmv, re.I):
                cfg_style(s, ea=norm.get('ea'), sz=body_sz)
                derived.append(sid)
        dd = sroot.find(q('docDefaults') + '/' + q('rPrDefault') + '/'
                        + q('rPr') + '/' + q('rFonts'))
        if dd is not None and norm.get('ea'):
            dd.set(W + 'eastAsia', norm['ea'])
        added_fig = add_fig_style(sroot, fig, ids['normal'], ids['charDefault'],
                                  args.keep_fig_indent)
        d.write(stree, 'styles.xml')

        # ---- document.xml
        dtree = d.parse('document.xml')
        droot = dtree.getroot()
        kids = body_children(dtree)

        # 1) 页面设置：每个 sectPr 都刷
        n_sect = 0
        for sect in droot.iter(q('sectPr')):
            pgsz = sect.find(q('pgSz'))
            if pgsz is not None:
                for k, v in spec['pgSz'].items():
                    if k.endswith('}w') or k.endswith('}h'):
                        pgsz.set(k, v)
            m = sect.find(q('pgMar'))
            if m is not None:
                for k, v in spec['pgMar'].items():
                    m.set(k, v)
            n_sect += 1

        # 2) 表格宽度按新版心重算
        cw_new = (int(spec['pgSz'].get(W + 'w', 11906))
                  - int(spec['pgMar'].get(W + 'right', 1800))
                  - int(spec['pgMar'].get(W + 'left', 1800)))
        n_tbl = 0
        if not args.no_table_rescale:
            for tbl in droot.iter(q('tbl')):
                cols = tbl.findall(q('tblGrid') + '/' + q('gridCol'))
                if not cols:
                    continue
                old = [int(c.get(W + 'w')) for c in cols]
                cw_old = sum(old)
                if cw_old == cw_new:
                    continue
                scale = cw_new / cw_old
                new = [round(v * scale) for v in old]
                new[-1] += cw_new - sum(new)
                for c, v in zip(cols, new):
                    c.set(W + 'w', str(v))
                tw = tbl.find(q('tblPr') + '/' + q('tblW'))
                if tw is not None and tw.get(W + 'type') == 'dxa':
                    tw.set(W + 'w', str(cw_new))
                mapping = dict(zip(old, new))
                for tc in tbl.iter(q('tcW')):
                    if tc.get(W + 'type') != 'dxa':
                        continue
                    v = int(tc.get(W + 'w'))
                    tc.set(W + 'w', str(mapping.get(v, round(v * scale))))
                n_tbl += 1

        # 3) 正文起点 + 主字号
        start = args.body_start if args.body_start is not None else \
            detect_body_start(kids, head_ids)
        dom = dominant_body_sz(kids, start, head_ids) or 21
        ratio = body_sz / dom

        # 4) 前置节（封面/目录）冻结行距——否则会继承 Normal 的新 1.5 倍
        for i in range(0, start):
            el = kids[i]
            if etree.QName(el).localname == 'p':
                set_spacing(el, line=240)
            elif etree.QName(el).localname == 'tbl':
                for p in el.iter(q('p')):
                    set_spacing(p, line=240)

        st = collections.Counter()
        head_line = {hid: (heads[i].get('line'), heads[i].get('before'),
                           heads[i].get('after'), heads[i].get('sz'))
                     for i, hid in enumerate(head_ids) if hid}

        for i in range(start, len(kids)):
            el = kids[i]
            tag = etree.QName(el).localname

            if tag == 'tbl':
                for p in el.iter(q('p')):
                    set_spacing(p, line=240)   # 表格不跟正文行距，否则整表撑高
                    for r in p.findall(q('r')):
                        if get_sz(r) is None:
                            continue
                        set_sz(r, tbl_sz)
                        if get_ea(r) and get_ea(r) != norm.get('ea') \
                                and get_ea(r) not in ('黑体',):
                            set_ea(r, norm['ea'])
                        st['table_run'] += 1
                continue

            if tag != 'p':
                continue
            runs = el.findall(q('r'))

            if has_drawing(el):
                set_spacing(el, line=240)
                continue

            txt = text_of(el)
            # --- 图注：套模板「图」样式
            if cap_re.match(txt.strip()):
                set_pstyle(el, FIG_STYLE_ID)
                set_spacing(el, line=240)
                set_flag(el, 'keepLines')
                for r in runs:
                    set_sz(r, fig['sz'])
                    set_ea(r, fig['ea'])
                    drop(r, 'b')
                    drop(r, 'bCs')
                st['caption'] += 1
                continue

            # --- 标题
            stv = get_pstyle(el)
            if stv in head_line:
                line, before, after, hsz = head_line[stv]
                for r in runs:
                    set_sz(r, hsz)
                set_spacing(el, line=line, before=before, after=after)
                set_flag(el, 'keepNext')
                set_flag(el, 'keepLines')
                st['heading'] += 1
                continue

            # --- 正文 / 注解
            is_body = True
            for r in runs:
                v = get_sz(r)
                if v is None:
                    continue
                if v in (dom, dom - 1):            # 正文字号（含差一档的变体）
                    set_sz(r, body_sz)
                    if get_ea(r) and get_ea(r) != norm.get('ea') and get_ea(r) != '黑体':
                        set_ea(r, norm['ea'])
                    st['body_run'] += 1
                elif v < dom - 1 and args.note_scale:   # 图后灰色注解一类的小字
                    set_sz(r, int(round(v * ratio)))
                    st['note_run'] += 1
                    is_body = False
                # v > dom：紫色小标题/内封大标题，属"现有设计"，不动
            set_spacing(el, line=norm.get('line', 360) if is_body else 300)

        d.write(dtree, 'document.xml')

    print(f'正文起点 body[{start}]｜检出正文主字号 sz={dom} -> {body_sz}（比例 {ratio:.3f}）')
    print(f'sectPr 刷新 {n_sect} 个｜表格重算 {n_tbl} 张（新版心 {cw_new} dxa）｜'
          f'表格文字 sz={tbl_sz}')
    print(f'派生正文样式 {derived}｜图样式新增: {added_fig}')
    print('run 改写：' + '、'.join(f'{k}={v}' for k, v in sorted(st.items())))


if __name__ == '__main__':
    main()
