#!/usr/bin/env python3
"""按图片真实宽高比分档定尺寸，并把图与图注绑定同页。

一刀切固定宽度（比如全部 600px）会同时制造两种毛病：宽扁图浪费版心，
竖高图撑破一页、把后面的内容整块推到下一页留下大片空白。分档规则：

    宽扁  w/h >= 1.6   ->  宽度取满 --max-width-px（默认 530px）
    方形  0.8 <= w/h   ->  限高 --square-max-h-pt（默认 300pt），宽度反推并封顶
    竖高  w/h <  0.8   ->  限高 --tall-max-h-pt（默认 340pt），宽度反推，不许超宽

图段落加 w:keepNext、紧随其后的图注段落加 w:keepLines，保证图与注不被分页拆开。

用法：
    python3 fit_images.py TARGET.docx [选项]

    python3 fit_images.py 手册.docx                       # 就地改，全部图片
    python3 fit_images.py 手册.docx --start-index 12      # 跳过封面（前 12 段）
    python3 fit_images.py 手册.docx --skip-images 2       # 跳过前 2 张图
    python3 fit_images.py 手册.docx --max-width-px 500 --square-max-h-pt 260
    python3 fit_images.py 手册.docx --dry-run             # 只报表格不落盘
"""
import argparse
import os
import re
import sys

from lxml import etree
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _docx_common import (  # noqa: E402
    A, EMU_PT, EMU_PX, R, W, WP, Docx, body_children, has_drawing, q,
    set_flag, set_spacing, text_of,
)


def plan_size(ar, max_w_px, wide_ar, tall_ar, square_h_pt, tall_h_pt):
    """返回 (cx, cy) EMU 与档名。"""
    if ar >= wide_ar:
        band = 'wide'
        w_px = float(max_w_px)
    elif ar >= tall_ar:
        band = 'square'
        w_px = min(float(max_w_px), square_h_pt * EMU_PT * ar / EMU_PX)
    else:
        band = 'tall'
        w_px = min(float(max_w_px), tall_h_pt * EMU_PT * ar / EMU_PX)
    cx = int(round(w_px * EMU_PX))
    cy = int(round(cx / ar))
    return cx, cy, band


def set_extent(drawing, cx, cy):
    """wp:extent 与 pic 里的 a:ext 都要改，只改一个 Word 会按另一个渲染。

    🔴 a:extLst 底下也有 a:ext，但那种带 uri 属性、没有 cx —— 碰它会造出非法属性。
    """
    for e in drawing.iter(WP + 'extent'):
        e.set('cx', str(cx))
        e.set('cy', str(cy))
    for e in drawing.iter(A + 'ext'):
        if e.get('cx') is not None:
            e.set('cx', str(cx))
            e.set('cy', str(cy))


def main():
    ap = argparse.ArgumentParser(description='docx 图片按宽高比分档定尺寸')
    ap.add_argument('target', help='目标 .docx（默认就地改）')
    ap.add_argument('--out', default=None, help='另存路径（不给则覆盖 target）')
    ap.add_argument('--max-width-px', type=int, default=530,
                    help='版心可用宽，默认 530px（A4 + 左右 1800dxa 边距）')
    ap.add_argument('--wide-ar', type=float, default=1.6, help='宽扁档下界 w/h')
    ap.add_argument('--tall-ar', type=float, default=0.8, help='竖高档上界 w/h')
    ap.add_argument('--square-max-h-pt', type=float, default=300,
                    help='方形档限高 pt')
    ap.add_argument('--tall-max-h-pt', type=float, default=340,
                    help='竖高档限高 pt')
    ap.add_argument('--start-index', type=int, default=0,
                    help='从第几个 body 段落开始处理（跳过封面用）')
    ap.add_argument('--skip-images', type=int, default=0,
                    help='跳过前 N 张图不动（跳过封面 logo/配图用）')
    ap.add_argument('--caption-regex', default=r'^图[\s　]*\d',
                    help='图注识别正则，默认匹配「图 1-1 ...」')
    ap.add_argument('--no-keep', action='store_true',
                    help='不加 keepNext / keepLines')
    ap.add_argument('--dry-run', action='store_true', help='只打印计划，不落盘')
    args = ap.parse_args()

    cap_re = re.compile(args.caption_regex)
    rows = []
    counts = {'wide': 0, 'square': 0, 'tall': 0}

    with Docx(args.target, out=args.out) as d:
        rels = {r.get('Id'): r.get('Target') for r in
                etree.parse(os.path.join(d.word, '_rels', 'document.xml.rels')).getroot()}
        dtree = d.parse('document.xml')
        kids = body_children(dtree)

        seen = 0
        for i, el in enumerate(kids):
            if etree.QName(el).localname != 'p' or not has_drawing(el):
                continue
            seen += 1
            if i < args.start_index or seen <= args.skip_images:
                continue
            drawing = el.find('.//' + q('drawing'))
            blip = drawing.find('.//' + A + 'blip')
            if blip is None:
                continue
            src = os.path.join(d.word, rels[blip.get(R + 'embed')])
            iw, ih = Image.open(src).size
            ar = iw / ih
            ext = drawing.find('.//' + WP + 'extent')
            old = (int(ext.get('cx')), int(ext.get('cy')))
            cx, cy, band = plan_size(ar, args.max_width_px, args.wide_ar,
                                     args.tall_ar, args.square_max_h_pt,
                                     args.tall_max_h_pt)
            counts[band] += 1
            rows.append((i, os.path.basename(src), f'{iw}x{ih}', round(ar, 3), band,
                         f'{round(old[0]/EMU_PX)}x{round(old[1]/EMU_PX)}',
                         f'{round(cx/EMU_PX)}x{round(cy/EMU_PX)}',
                         f'{round(cx/EMU_PT)}x{round(cy/EMU_PT)}'))
            if args.dry_run:
                continue
            set_extent(drawing, cx, cy)
            set_spacing(el, line=240)
            if not args.no_keep:
                set_flag(el, 'keepNext')
                # 紧随其后的图注段落绑 keepLines
                if i + 1 < len(kids):
                    nxt = kids[i + 1]
                    if etree.QName(nxt).localname == 'p' \
                            and cap_re.match(text_of(nxt).strip()):
                        set_flag(nxt, 'keepLines')

        if args.dry_run:
            # 抛异常让 Docx.__exit__ 跳过回包（干跑不落盘）
            _report(rows, counts, args)
            raise SystemExit(0)
        d.write(dtree, 'document.xml')

    _report(rows, counts, args)


def _report(rows, counts, args):
    hdr = f'{"idx":>4} {"file":<16} {"源尺寸":<12} {"ar":>6} {"档":<7} ' \
          f'{"原(px)":<12} {"新(px)":<12} 新(pt)'
    print(hdr)
    for r in rows:
        print(f'{r[0]:>4} {r[1]:<16} {r[2]:<12} {r[3]:>6} {r[4]:<7} '
              f'{r[5]:<12} {r[6]:<12} {r[7]}')
    print(f'\n共 {len(rows)} 张：宽扁 {counts["wide"]} / 方形 {counts["square"]} '
          f'/ 竖高 {counts["tall"]}'
          f'（判据 wide>={args.wide_ar}, tall<{args.tall_ar}；'
          f'宽上限 {args.max_width_px}px，方形限高 {args.square_max_h_pt}pt，'
          f'竖高限高 {args.tall_max_h_pt}pt）')
    return 0


if __name__ == '__main__':
    main()
